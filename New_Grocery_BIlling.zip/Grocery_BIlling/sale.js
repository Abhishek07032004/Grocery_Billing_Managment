document.getElementById("demo").innerHTML=(new Date().toLocaleDateString('en-GB'));
function back(){
    window.location.href="welcomehome.php";
}