document.getElementById("date").innerHTML=(new Date().toLocaleDateString('en-GB'));


 